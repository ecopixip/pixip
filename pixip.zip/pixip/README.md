# PIXIP – Fase 1 (CORE SYSTEM)

Este repositório contém a **Fase 1 do PIXIP**, incluindo:

- Backend Node.js + Express + MySQL
- Frontend React + Vite
- Scripts de instalação e deploy para Ubuntu 24
- Estrutura básica para leads, usuários e histórico de ações

---

## 📦 Estrutura do Projeto

