export default function Navbar() {
  return (
    <nav className="navbar">
      <h1>PIXIP</h1>
    </nav>
  );
}
