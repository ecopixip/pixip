export default function UserPanel() {
  return (
    <div>
      <p>Admin: admin@pixip.com</p>
      <p>Perfil: Administrador</p>
    </div>
  );
}
