export default function Sidebar() {
  return (
    <aside className="sidebar">
      <ul>
        <li>Dashboard</li>
        <li>Leads</li>
        <li>Usuários</li>
        <li>Configurações</li>
      </ul>
    </aside>
  );
}
